var APP_DATA = {
  "scenes": [
    {
      "id": "0-07_chambre-2-1",
      "name": "07_Chambre 2 (1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.4017902613033932,
          "pitch": 0.4799220452369184,
          "rotation": 0,
          "target": "1-06_chambre-1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-06_chambre-1",
      "name": "06_Chambre 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.37641636972209014,
          "pitch": 0.5635622500378403,
          "rotation": 5.497787143782138,
          "target": "0-07_chambre-2-1"
        },
        {
          "yaw": 1.7105898369163963,
          "pitch": 0.5371157584742718,
          "rotation": 0,
          "target": "6-01_hall-dentre-"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-05_cuisine",
      "name": "05_Cuisine",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.599459485910419,
          "pitch": 0.590007107270214,
          "rotation": 5.497787143782138,
          "target": "5-02_hall-dentre-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-04_sjour-",
      "name": "04_Séjour ",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.3557387610844884,
          "pitch": 0.5502877064623224,
          "rotation": 0,
          "target": "5-02_hall-dentre-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-03_salle-deau",
      "name": "03_Salle d’eau",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.5686216564735638,
          "pitch": 0.7505354254649905,
          "rotation": 0,
          "target": "5-02_hall-dentre-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5-02_hall-dentre-2",
      "name": "02_Hall d’entrée 2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.9751218716132293,
          "pitch": 0.9670972440340755,
          "rotation": 0,
          "target": "4-03_salle-deau"
        },
        {
          "yaw": -0.7783295792036089,
          "pitch": 0.6324266348390584,
          "rotation": 0,
          "target": "3-04_sjour-"
        },
        {
          "yaw": -0.22478752531884183,
          "pitch": 0.6968476184771326,
          "rotation": 0.7853981633974483,
          "target": "2-05_cuisine"
        },
        {
          "yaw": 2.0654200738940247,
          "pitch": 0.9306121956966251,
          "rotation": 0,
          "target": "6-01_hall-dentre-"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "6-01_hall-dentre-",
      "name": "01_Hall d’entrée ",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "yaw": 1.1867218337999645,
        "pitch": 0,
        "fov": 1.3365071038314758
      },
      "linkHotspots": [
        {
          "yaw": 0.5978127486780114,
          "pitch": 0.29705005797714534,
          "rotation": 0,
          "target": "5-02_hall-dentre-2"
        },
        {
          "yaw": -2.682678692276564,
          "pitch": 0.6860274627955825,
          "rotation": 7.0685834705770345,
          "target": "1-06_chambre-1"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": false
  }
};
